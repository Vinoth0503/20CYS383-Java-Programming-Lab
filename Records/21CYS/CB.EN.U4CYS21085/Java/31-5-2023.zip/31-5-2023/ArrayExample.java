public class ArrayExample {
    public static void main(String[] args) {
        String[] names = new String[6];

        names[0] = "Vinoth";
        names[1] = "Santy";
        names[2] = "Laks";

        for (int i = 0; i < names.length; i++) {
            System.out.println(names[i]);
        }
    }
}
