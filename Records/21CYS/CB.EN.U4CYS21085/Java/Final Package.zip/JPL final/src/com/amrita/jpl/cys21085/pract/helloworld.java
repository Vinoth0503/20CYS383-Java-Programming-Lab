package com.amrita.jpl.cys21085.pract;

/**
 * @authhor - Vinoth Kumar C [CB.EN.U4CYS21085]
 * A simple program that prints "Hello world!" to the console.
 */
public class helloworld {
    /**
     * The main method is the entry point of the program.
     *
     * @param args the command-line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}
