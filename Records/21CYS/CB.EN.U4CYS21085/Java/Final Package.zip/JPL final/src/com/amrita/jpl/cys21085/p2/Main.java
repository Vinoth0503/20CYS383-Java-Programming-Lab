/**
package com.amrita.jpl.cys21085.p2;
class Main {
    public static void main(String[] args) {
        com.amrita.jpl.cys21085.p2.QuizGameServer server = new QuizGameServer();
        com.amrita.jpl.cys21085.p2.QuizGameClient client = new QuizGameClient(server);

        client.startGame();
    }
}
**/