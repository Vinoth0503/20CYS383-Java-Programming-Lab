package com.amrita.jpl.cys21085.pract;
/**
 * @authhor - Vinoth Kumar C [CB.EN.U4CYS21085]
 * This program calculates the sum of two numbers and prints the result.
 */
public class add2no {
    /**
     * The main method is the entry point of the program.
     *
     * @param args the command-line arguments
     */
    public static void main(String args[]) {
        int n1 = 10;
        int n2 = 10;
        int sum;
        sum = n1 + n2;
        System.out.println("The sum of 2 numbers is: " + sum);
    }
}
