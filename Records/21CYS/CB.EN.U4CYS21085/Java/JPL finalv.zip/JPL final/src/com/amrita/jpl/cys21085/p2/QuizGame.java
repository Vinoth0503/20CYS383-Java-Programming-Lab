
package com.amrita.jpl.cys21085.p2;
abstract class QuizGame {
    abstract void startGame();
    abstract void askQuestion();
    abstract void evaluateAnswer(String answer);
}
