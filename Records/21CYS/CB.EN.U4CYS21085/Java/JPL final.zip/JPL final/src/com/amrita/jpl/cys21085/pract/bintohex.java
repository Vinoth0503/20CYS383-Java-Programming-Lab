package com.amrita.jpl.cys21085;

import java.util.Scanner;
public class bintohex {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get decimal input from user
        System.out.print("Enter a decimal number: ");
        int decimal = scanner.nextInt();

        // Check if the input is negative
        if (decimal < 0) {
            System.out.println("Error: Input must be a positive integer.");
            return;
        }

        // Convert to binary and hexadecimal
        String binary = Integer.toBinaryString(decimal);
        String hexadecimal = Integer.toHexString(decimal);

        // Print the results
        System.out.println("Binary: " + binary);
        System.out.println("Hexadecimal: " + hexadecimal);
    }
}