package com.amrita.jpl.cys21085;

public class add2no
{
    public static void main(String args[]) {
        int n1 = 10;
        int n2 = 10;
        int sum;
        sum = n1 + n2;
        System.out.println("The sum of 2 numbers is: " + sum);
    }

}