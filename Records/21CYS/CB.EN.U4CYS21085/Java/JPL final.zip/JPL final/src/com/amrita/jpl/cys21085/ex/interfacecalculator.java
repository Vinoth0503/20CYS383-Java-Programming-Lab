package com.amrita.jpl.cys21085.ex;


import java.util.Scanner;

public class interfacecalculator {
    interface Calculator {
        double add(double num1, double num2);
        double subtract(double num1, double num2);
        double multiply(double num1, double num2);
        double divide(double num1, double num2) throws ArithmeticException;
    }

    static class BasicCalculator implements Calculator {
        public double add(double num1, double num2) {
            return num1 + num2;
        }

        public double subtract(double num1, double num2) {
            return num1 - num2;
        }

        public double multiply(double num1, double num2) {
            return num1 * num2;
        }

        public double divide(double num1, double num2) throws ArithmeticException {
            if (num2 == 0) {
                throw new ArithmeticException("Division by zero is not allowed.");
            }
            return num1 / num2;
        }
    }

    public static void main(String[] args) {
        BasicCalculator calculator = new BasicCalculator();
        double num1, num2;

        Scanner myObj = new Scanner(System.in);
        num1 = myObj.nextDouble();
        num2 = myObj.nextDouble();


        double sum = calculator.add(num1, num2);
        double difference = calculator.subtract(num1, num2);
        double product = calculator.multiply(num1, num2);
        double quotient;
        System.out.println("Addition: " + sum);
        System.out.println("Subtraction: " + difference);
        System.out.println("Multiplication: " + product);
        try {
            quotient = calculator.divide(num1, num2);
            System.out.println("Division: " + quotient);
        } catch (ArithmeticException e) {
            System.out.println("Division by zero error!");
            System.out.println("Division: -1.0");
        }

    }
}