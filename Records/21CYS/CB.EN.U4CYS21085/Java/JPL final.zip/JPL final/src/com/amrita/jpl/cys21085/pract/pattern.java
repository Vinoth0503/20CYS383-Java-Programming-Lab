package com.amrita.jpl.cys21085;

public class pattern {
    public static void main(String[] args) {
        for (int i = 0; i < 6; i++) {
            System.out.println("* * * * * * ==================================");
            System.out.println(" * * * * *  ===================================");
        }
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
        System.out.println("==============================================");
    }
}
