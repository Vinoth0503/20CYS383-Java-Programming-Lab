package com.amrita.jpl.cys21085;

public class helloworld {
    public static void main(String[] args) {

        System.out.println("Hello world!");
    }
}
